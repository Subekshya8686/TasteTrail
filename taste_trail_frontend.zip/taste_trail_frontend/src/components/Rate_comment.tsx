import React, { useState } from 'react';
import '../pages1/css/Recipes.css'

interface RecipeRateCommentProps {
    onRate: (rating: number) => void;
    onComment: (comment: string) => void;
}

const Rate_comment: React.FC<RecipeRateCommentProps> = ({ onRate, onComment }) => {
    const [rating, setRating] = useState<number | null>(null);
    const [comment, setComment] = useState<string>('');

    const handleRate = (value: number) => {
        setRating(value);
        onRate(value);
    };

    const handleCommentChange = (event: React.ChangeEvent<HTMLTextAreaElement>) => {
        setComment(event.target.value);
    };

    const handleCommentSubmit = (event: React.FormEvent) => {
        event.preventDefault();
        onComment(comment);
        setComment('');
    };

    return (
        <div className="recipe-rate-comment">
            <div className="rating-section">
                <p>Rate this recipe:</p>
                {[1, 2, 3, 4, 5].map((value) => (
                    <span key={value} onClick={() => handleRate(value)} className={value <= (rating || 0) ? 'active' : ''}>
            ★
          </span>
                ))}
            </div>

            <div className="comment-section">
                <p>Leave a comment:</p>
                <form onSubmit={handleCommentSubmit}>
          <textarea
              rows={4}
              placeholder="Type your comment here..."
              value={comment}
              onChange={handleCommentChange}
          />
                    <button type="submit">Submit</button>
                </form>
            </div>
        </div>
    );
};

export default Rate_comment;
